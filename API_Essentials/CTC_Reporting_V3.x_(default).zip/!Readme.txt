To leverage the Reporting API you will need to acquire your reporting key from CTC Software
Email: LicenseRequest@ctcsoftware.com
Subject: ReportingAPI Key Request

Excel:
1) Open the Excel File

2) Enable the External Content

3) Use the reporting API key you receive to update the ReportKey parmeter found at:
 Data -> Queries & Connections -> Parameters -> reportApiKey

4) Save and close the Query Settings

5) Save the Excel File

6) Use Data -> Refresh All to refresh the base data

7) The first refresh will pop a message asking about Privacy Levels. Check 'Ignore All' for this file.

8) Allow the refresh to complete and save the Excel file


Power BI:
1) Open the PowerBI file

2) In PowerBI Desktop use Home -> Transform Data -> Edit Parameters to update the full path to your XLS file.

3) Save the PowerBI file

4) Use Home -> Refresh to refresh all of the data from the excel file

5) Save the PowerBI file and have fun navigating the data
